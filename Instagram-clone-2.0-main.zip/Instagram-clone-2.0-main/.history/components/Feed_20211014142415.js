import React from "react";

function Feed() {
  return (
    <main>
    <section>
         {/*Section*/}
        {/*Stories*/}
        {/*Post*/}
    </section>

    {
    </main>
  );
}

export default Feed;
