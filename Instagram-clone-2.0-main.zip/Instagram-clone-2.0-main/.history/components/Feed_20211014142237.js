import React from "react";

function Feed() {
  return (
    <div>
      {/*Section*/}

      {/*Stories*/}
      
      {/*Post*/}
    </div>
  );
}

export default Feed;
