import React from "react";
import Image from "next/image";

function Header() {
  return (
    <div className="header">
      <div className="flex justify-between max-w-6xl">
        {/* Left*/}
        <div className="relative h-24 w-24">
          <Image
            src="https://links.papareact.com/ocw"
            layout="fill"
            objectFit="contain"
          />
        </div>
        <h1>helloworld</h1>
        {/* Middle */}

        {/* Right */}
      </div>
    </div>
  );
}

export default Header;
