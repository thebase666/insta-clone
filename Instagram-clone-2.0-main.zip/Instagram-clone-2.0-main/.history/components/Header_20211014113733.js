import React from "react";
import Image from "next/image";

function Header() {
  return (
    <div className="header">
      <h1>i am a header</h1>
      {/* Left*/}
      <div>
        <Image 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Instagram_logo.svg/2880px-Instagram_logo.svg.png"
        />
      </div>

      {/* Middle */}

      {/* Right */}
    </div>
  );
}

export default Header;
