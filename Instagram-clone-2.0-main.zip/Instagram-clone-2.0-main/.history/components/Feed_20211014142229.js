import React from 'react'

function Feed() {
    return (
        <div>
        {/*Section */ }
        {/*Stories*/ }
        {/*post*/ }
            
        </div>
    )
}

export default Feed
