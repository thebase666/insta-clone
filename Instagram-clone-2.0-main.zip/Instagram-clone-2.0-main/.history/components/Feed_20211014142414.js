import React from "react";

function Feed() {
  return (
    <main>
    <section>
        
    </section>

    {
    </main>
  );
}

export default Feed;
