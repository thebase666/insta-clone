import React from "react";
import Stories from "./Stories";

function Feed() {
  return (
    <main>
      <section>
        {/*Section*/}
        {/*Stories*/}
        <Stories />
        {/*Post*/}
      </section>

      <section>
        {/*Mini profile*/}
        {/*Sugesstions  */}
        
      </section>
    </main>
  );
}

export default Feed;
