import React from "react";

function Feed() {
  return (
    <main>
    {/*Section*/}
        {/*Stories*/}
        {/*Post*/}

    {
    </main>
  );
}

export default Feed;
