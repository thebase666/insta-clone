import React from "react";
import

function Header() {
  return (
    <div className="header">
      <h1>i am a header</h1>
      {/* Left*/}
      <div>
          <Image />
      </div>

      {/* Middle */}

      {/* Right */}
    </div>
  );
}

export default Header;
