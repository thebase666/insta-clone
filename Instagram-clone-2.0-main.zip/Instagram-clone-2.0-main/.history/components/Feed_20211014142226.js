import React from 'react'

function Feed() {
    return (
        <div>
        {/*Section */ }
        {/*Stories*/ }
        {/**/ }
            
        </div>
    )
}

export default Feed
