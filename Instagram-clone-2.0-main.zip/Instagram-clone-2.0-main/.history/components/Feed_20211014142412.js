import React from "react";

function Feed() {
  return (
    <main>
    sect

    {
    </main>
  );
}

export default Feed;
