import React from "react";
import Image from "next/image";

function Header() {
  return (
    <div className="header">
      <h1>i am a header</h1>
      {/* Left*/}
      <div className="re" >
        <Image src="https://links.papareact.com/ocw" layout="fill" />
      </div>

      {/* Middle */}

      {/* Right */}
    </div>
  );
}

export default Header;
