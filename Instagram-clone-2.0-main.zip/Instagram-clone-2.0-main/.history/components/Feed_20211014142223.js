import React from 'react'

function Feed() {
    return (
        <div>
        {/*Section */ }
        {/**/ }
        {/**/ }
            
        </div>
    )
}

export default Feed
