import React from "react";
import Image from "next/image";

function Header() {
  return (
    <div className="header">
    div
      {/* Left*/}
      <div className="relative w-24">
        <Image src="https://links.papareact.com/ocw" layout="fill" />
      </div>

      {/* Middle */}

      {/* Right */}
    </div>
  );
}

export default Header;
