import React from "react";
import Image from "next/image";

function Header() {
  return (
    <div className="header">
    
    
     
    </div>
  );
}

export default Header;
