import React from "react";

function Feed() {
  return (
    <main>
      <section>
        {/*Section*/}
        {/*Stories*/}
        <Stories
        
        {/*Post*/}
      </section>

      <section>
        {/*Mini profile*/}
        {/*Sugesstions  */}
        
      </section>
    </main>
  );
}

export default Feed;
