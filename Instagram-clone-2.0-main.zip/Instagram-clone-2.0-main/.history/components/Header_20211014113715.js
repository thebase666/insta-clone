import React from "react";
import Image from "next/image";

function Header() {
  return (
    <div className="header">
      <h1>i am a header</h1>
      {/* Left*/}
      <div>
        <Image 
            src=""
        />
      </div>

      {/* Middle */}

      {/* Right */}
    </div>
  );
}

export default Header;
