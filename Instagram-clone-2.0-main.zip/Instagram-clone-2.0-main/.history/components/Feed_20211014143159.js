import React from "react";
import Stories from "./Stories";

function Feed() {
  return (
    <main className=é >
      <section>
        {/*Stories*/}
        <Stories />
        {/*Post*/}
      </section>

      <section>
        {/*Mini profile*/}
        {/*Sugesstions  */}
      </section>
    </main>
  );
}

export default Feed;
