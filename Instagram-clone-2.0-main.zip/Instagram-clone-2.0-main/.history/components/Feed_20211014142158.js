import React from 'react'

function Feed() {
    return (
        <div>
        {/*/}
            
        </div>
    )
}

export default Feed
