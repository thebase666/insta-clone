
export const modalState = atom